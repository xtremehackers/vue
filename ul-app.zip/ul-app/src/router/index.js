import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import NotFound from '../components/GeneralViews/NotFoundPage.vue'
import DashboardLayout from '../components/Dashboard/Layout/DashboardLayout.vue'
import Overview from '../components/Dashboard/Views/overview.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
        path: '/',
        component: DashboardLayout,
        redirect: '/dashboard'
    },
    {
        path: '/dashboard',
        component: DashboardLayout,
        redirect: '/dashboard/overview',
        children: [
          {
            path: 'overview',
            name: 'overview',
            component: Overview
          }
        ]
    },
    { 
        path: '*', 
        component: NotFound 
    }
  ]
})
