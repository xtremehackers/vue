<template>
  <p>Not Found</p>
</template>

<script>
  export default {}

</script>
